"""
Polygraph Agent — слой инструментов (function calling).

Поддерживает:
  - OpenRouter (через OpenAI-совместимый tools API)
  - Google Gemini (через нативный function calling)
"""

import json, time, os, inspect
from typing import Any
from dataclasses import dataclass


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    func: Any

    def call(self, **kw) -> str:
        try:
            # Отфильтровываем аргументы, которых нет в сигнатуре функции,
            # чтобы лишний/неверно названный ключ от модели не ронял вызов.
            sig = inspect.signature(self.func)
            accepts_kwargs = any(
                p.kind == inspect.Parameter.VAR_KEYWORD
                for p in sig.parameters.values()
            )
            if not accepts_kwargs:
                allowed = set(sig.parameters)
                kw = {k: v for k, v in kw.items() if k in allowed}
            return str(self.func(**kw))
        except Exception as e:
            return f"[tool error] {e}"


class Agent:
    """Инструментальный слой над Polygraph."""

    def __init__(self, pg, debug: bool = False):
        self.pg = pg
        self.tools: dict[str, Tool] = {}
        self.debug = debug
        self.last_model = ""  # какая модель ответила в последний раз
        self.force_model = ""  # принудительная модель (алиас), напр. "gpt-oss" / "gemini"
        self.session_model = None  # (provider, model_id) — закреплённая на сессию модель
        # Шаг 1 Фазы 3: лог сообщений последнего turn-а (для честной истории диалога).
        # Заполняется внутри _run_via_openai_compat / _run_via_google.
        # Формат: список dict в OpenAI-стиле: {role, content, tool_calls?, tool_call_id?, name?}
        self.last_messages: list[dict] = []

    def register(self, tool: Tool):
        self.tools[tool.name] = tool

    def _tools_schema(self) -> list[dict]:
        return [{"type":"function","function":{
            "name":t.name,"description":t.description,"parameters":t.parameters
        }} for t in self.tools.values()]

    # ===== Google Gemini (нативный function calling) =====
    def _openai_msgs_to_gemini(self, messages: list[dict]):
        """
        Шаг 3 Фазы 3: конвертирует OpenAI-формат messages в нативный Gemini contents.
        Принимает: список dict с ролями user/assistant/tool (+ tool_calls для assistant).
        Возвращает: список объектов для поля contents Gemini API.
        Системные сообщения игнорируются (они идут отдельно в system_instruction).
        """
        from google.genai import types as gt
        contents = []
        # карта tool_call_id → name, чтобы при tool-ответе знать имя функции
        call_id_to_name: dict[str, str] = {}

        for m in messages:
            role = m.get("role")
            if role == "system":
                continue  # отдельно через system_instruction
            if role == "user":
                content = m.get("content", "") or ""
                if content:
                    contents.append(gt.Content(role="user", parts=[gt.Part.from_text(text=content)]))
            elif role == "assistant":
                parts = []
                # сначала текст (если был)
                text = m.get("content", "") or ""
                if text:
                    parts.append(gt.Part.from_text(text=text))
                # потом tool_calls (если были)
                for tc in (m.get("tool_calls") or []):
                    fn = tc.get("function", {})
                    fname = fn.get("name", "")
                    try:
                        fargs = json.loads(fn.get("arguments") or "{}")
                    except Exception:
                        fargs = {}
                    parts.append(gt.Part.from_function_call(name=fname, args=fargs))
                    call_id_to_name[tc.get("id", "")] = fname
                if parts:
                    contents.append(gt.Content(role="model", parts=parts))
            elif role == "tool":
                # ответ инструмента
                tcid = m.get("tool_call_id", "")
                fname = m.get("name") or call_id_to_name.get(tcid, "unknown")
                result = m.get("content", "") or ""
                contents.append(gt.Content(role="user", parts=[
                    gt.Part.from_function_response(name=fname, response={"result": result})
                ]))
        return contents

    def _run_via_google(self, msg: str, max_turns: int = 5,
                        prior_messages: list[dict] | None = None) -> str | None:
        prov = self.pg.providers.get("google")
        if not prov or not prov.ok:
            return None

        # Конвертируем инструменты в формат Gemini
        from google.genai import types as gt
        gemini_tools = []
        for t in self.tools.values():
            # Конвертируем JSON Schema параметры в формат Gemini Schema
            gemini_tools.append(gt.Tool(
                function_declarations=[gt.FunctionDeclaration(
                    name=t.name,
                    description=t.description,
                    parameters=json.loads(json.dumps(t.parameters))  # через JSON чтобы убрать лишнее
                )]
            ))

        # Фикс W1 из аудита: SYS_PROMPT теперь идёт в system_instruction
        # (правильное поле Gemini), а не как обычный user-message в contents.
        # Это улучшает следование правилам и экономит контекст.
        config = gt.GenerateContentConfig(
            tools=gemini_tools,
            max_output_tokens=2048,
            system_instruction=self.SYS_PROMPT,
        )

        # Шаг 3 Фазы 3: начинаем с истории прошлых turn-ов (если передана),
        # потом добавляем текущий user-message.
        contents = []
        if prior_messages:
            try:
                contents = self._openai_msgs_to_gemini(prior_messages)
            except Exception as e:
                if self.debug:
                    print(f"   [gemini history convert error] {e}")
                contents = []  # если конвертация упала — продолжим без истории
        contents.append(gt.Content(role="user", parts=[gt.Part.from_text(text=msg)]))

        # Зеркальный лог (без system, без prior) — только текущий turn для last_messages
        mirror_log: list[dict] = [{"role": "user", "content": msg}]
        pending_calls: list[dict] = []  # tool_calls, ожидающие парных tool-ответов

        for _ in range(max_turns):
            try:
                resp = prov.c.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=contents,
                    config=config,
                )

                # Проверяем function calls
                if resp.candidates and resp.candidates[0].content and resp.candidates[0].content.parts:
                    parts = resp.candidates[0].content.parts
                    fc_found = False
                    response_text = ""

                    # Сначала добавляем ответ модели (с function_call) в историю,
                    # иначе Gemini не сможет сопоставить function_response.
                    contents.append(resp.candidates[0].content)

                    # Соберём все tool_calls этого ассистент-турна в одном сообщении лога
                    turn_tool_calls = []
                    turn_text_parts = []
                    for part in parts:
                        if hasattr(part, 'function_call') and part.function_call:
                            fc_found = True
                            fname = part.function_call.name
                            fargs = dict(part.function_call.args or {})
                            # Выполняем инструмент РОВНО один раз
                            result = self._execute_tool(fname, fargs)
                            if self.debug:
                                print(f"   [gemini tool] {fname}({fargs}) -> {result[:120]}")
                            contents.append(gt.Part.from_function_response(
                                name=fname,
                                response={"result": result},
                            ))
                            # Зеркало для лога (OpenAI-стиль)
                            call_id = f"gem_{len(mirror_log)}_{fname}"
                            turn_tool_calls.append({
                                "id": call_id, "type": "function",
                                "function": {"name": fname, "arguments": json.dumps(fargs, ensure_ascii=False)}
                            })
                            pending_calls.append({"id": call_id, "name": fname, "result": result})
                        elif hasattr(part, 'text') and part.text:
                            response_text += part.text
                            turn_text_parts.append(part.text)

                    # Записываем ассистент-сообщение в зеркальный лог
                    if turn_tool_calls or turn_text_parts:
                        mirror_log.append({
                            "role": "assistant",
                            "content": "".join(turn_text_parts),
                            **({"tool_calls": turn_tool_calls} if turn_tool_calls else {})
                        })
                    # И ответы инструментов сразу после
                    for pc in pending_calls:
                        mirror_log.append({
                            "role": "tool", "tool_call_id": pc["id"],
                            "name": pc["name"], "content": pc["result"]
                        })
                    pending_calls = []

                    if not fc_found:
                        self.last_model = "google/gemini-2.5-flash"
                        self.last_messages = mirror_log
                        return response_text or "[no response]"
                else:
                    self.last_model = "google/gemini-2.5-flash"
                    final_text = str(resp.text) if hasattr(resp, 'text') else "[no response]"
                    mirror_log.append({"role": "assistant", "content": final_text})
                    self.last_messages = mirror_log
                    return final_text

            except Exception as e:
                if self.debug:
                    print(f"   [gemini error] {type(e).__name__}: {e}")
                return None  # Пробуем следующий провайдер

        return "[max turns]"

    def _execute_tool(self, name: str, args: dict) -> str:
        tool = self.tools.get(name)
        result = tool.call(**args) if tool else f"[tool not found: {name}]"
        # Постоянное логирование tool-вызовов в файл (Фаза 4 диагностика).
        # Работает всегда, не зависит от self.debug. Помогает разбирать проблемы
        # постфактум без переключения debug=True/False.
        try:
            import os as _os, time as _t, json as _j
            log_dir = _os.path.join("agent_files")
            _os.makedirs(log_dir, exist_ok=True)
            with open(_os.path.join(log_dir, "tool_calls.log"), "a", encoding="utf-8") as _f:
                _f.write(_j.dumps({
                    "ts": _t.strftime("%Y-%m-%d %H:%M:%S"),
                    "tool": name,
                    "args": args,
                    "result_preview": str(result)[:500],
                    "result_len": len(str(result)),
                }, ensure_ascii=False) + "\n")
        except Exception:
            pass  # никогда не ломаем основной поток из-за логирования
        return result

    # ===== OpenAI-совместимый function calling (Groq, OpenRouter, Cerebras, Mistral) =====
    SYS_PROMPT = (
        "Ты — Polygraph, умный, дружелюбный и живой помощник во всём. Общаешься на «ты», "
        "тепло и по-человечески, как хороший друг-эксперт, а не робот-справочник. У тебя "
        "есть инструменты — сам решаешь, когда они нужны. Сейчас 2026 год.\n\n"

        "🎯 ТВОЯ РОЛЬ: универсальный ассистент. Помогаешь во ВСЁМ — писать тексты, "
        "разбираться в коде, объяснять сложные темы, искать информацию, считать, "
        "анализировать документы и картинки, обсуждать идеи, давать житейские советы, "
        "переводить, придумывать названия, помогать с обучением, работой, проектами. "
        "Бизнес, маркетплейсы (WB/Ozon), юридика, медицина, финансы, наука, творчество, "
        "программирование, повседневные вопросы — на всё умеешь. На чувствительных темах "
        "(медицина, юридика, финансы, психология) честно отмечай «я не врач/юрист/"
        "финконсультант», но НЕ занудствуй — дай нормальный полезный ответ + рекомендацию "
        "уточнить у специалиста, если случай серьёзный.\n\n"

        "СТИЛЬ И ПОВЕДЕНИЕ:\n"
        "• Говори естественно, живым языком, лёгкие эмодзи где уместно. 🙂\n"
        "• Здоровайся ТОЛЬКО в первом сообщении беседы. Если в истории уже есть твои "
        "реплики — не здоровайся, сразу к делу.\n"
        "• Длину ответа подстраивай под вопрос: простой/бытовой → коротко, без простыней "
        "и таблиц; развёрнутый разбор (разделы, таблицы, источники) — только когда просят "
        "анализ/сравнение/исследование или это явно нужно.\n"
        "• ⚠️ СНАЧАЛА ответь на сам вопрос, и только ПОТОМ (по желанию) предложи следующий "
        "шаг. Никогда не начинай с «что ещё?» вместо ответа. На «2+2» отвечай «4», на "
        "«15% от 3400» — «510 ₽», и лишь затем, если хочешь, доп. вопрос.\n"
        "• Если запрос размытый/неоднозначный или не хватает деталей — не гадай вслепую, "
        "задай 1-2 коротких уточняющих вопроса (можно с вариантами), потом действуй. "
        "Если ясно — не тяни, помогай сразу.\n\n"

        "🧭 КАК ДУМАТЬ НАД ЗАПРОСОМ (про себя): пойми намерение → реши, нужны ли "
        "инструменты → если задача сложная, составь план из шагов (найти → прочитать → "
        "посчитать → ответить) → выполни, дождись РЕАЛЬНЫХ результатов → синтезируй ответ "
        "только на их основе. Типы: болтовня/приветствие, общеизвестный факт, написание "
        "текста, объяснение, совет, рассуждение → БЕЗ инструментов, на своих знаниях; "
        "актуальное/новости/«найди»/обзор/сравнение/факты с цифрами → deep_research; "
        "расчёты/анализ данных/код → run_python; описать картинку → analyze_image; "
        "нарисовать → generate_image; файлы → read_file/write_file/list_files. Не зови "
        "инструмент зря (на «напиши стих про осень» интернет не нужен), но для свежих "
        "фактов из интернета / расчётов / анализа картинок — зови обязательно.\n\n"

        "ИНСТРУМЕНТЫ:\n"
        "• deep_research — глубокое исследование (поиск + чтение страниц + источники). "
        "web_search — быстрый поиск. fetch_url — прочитать страницу по ссылке.\n"
        "• generate_image — нарисовать изображение по описанию (промпт переводи на "
        "английский для качества). ⚠️ Если в запросе нет картинки и про изображение не "
        "просят — НЕ упоминай картинки и не проси их прислать, просто отвечай на вопрос.\n"
        "• analyze_image — посмотреть изображение (фото, скриншот, карточку, документ) "
        "по пути к файлу или URL. Правила:\n"
        "    – Есть ссылка на картинку или просьба её описать → ВСЕГДА вызывай "
        "analyze_image, не отвечай «не могу посмотреть» (инструмент есть). Если ссылка "
        "была выше в диалоге — найди её в истории и передай.\n"
        "    – НИКОГДА не угадывай содержимое по имени файла или адресу. Сначала ПОСМОТРИ, "
        "потом описывай.\n"
        "    – 📊 СКРИНШОТ С ДАННЫМИ (таблица тарифов, прайс, отчёт, график, чек, "
        "договор, документ, сообщение, расписание, билет, рецепт) — лучший источник "
        "истины. Переноси цифры/текст как есть: не округляй, не путай колонки/строки, "
        "не дополняй из памяти; нечитаемое/обрезанное — честно отметь. Извлечённые со "
        "скрина данные называть МОЖНО. Если в таблице есть колонки с похожими именами "
        "(например FBW/FBS/DBS у WB, или дебет/кредит в выписке) — НЕ смешивай их.\n"
        "• run_python — вычисления, анализ данных, проверка кода, обработка строк.\n"
        "• 📺 watch_youtube — читает СУБТИТРЫ YouTube-видео (текст + тайм-коды). "
        "🚨 ПРАВИЛО: на ЛЮБУЮ ссылку YouTube (youtube.com/watch, youtu.be, shorts) → "
        "ОБЯЗАТЕЛЬНО сразу вызови watch_youtube. ЗАПРЕЩЕНО отвечать «не могу», «нет "
        "доступа», «установи библиотеку», «давай поищу описание» — инструмент УЖЕ есть, "
        "работает без ключей, нужно просто его ВЫЗВАТЬ. Только если инструмент реально "
        "вернёт ошибку — тогда честно сообщи (нет субтитров / приват / live).\n"
        "• 📄 read_file для PDF: пэрсит длинные документы, аргумент pages='1-10' / "
        "'last10' / 'all' для навигации. search_pdf — поиск ключевого слова по всему PDF. "
        "analyze_pdf_page — Vision-fallback для PDF из сканов (ДОРОГО, только когда read_file пуст).\n\n"

        "🔎 КАЧЕСТВЕННЫЙ ПОИСК:\n"
        "• Запрос формулируй конкретно (ключевые слова, номера, год); для фактов добавляй "
        "«официальный»/«текст»/«2026». Не «оферта WB», а «оферта Wildberries пункт 9.7.2 "
        "текст». Не «как лечить кашель», а «кашель сухой ночной причины 2026 рекомендации».\n"
        "• Мало/мусорные результаты — переформулируй (синонимы, рус+англ) и попробуй снова. "
        "Один запрос — не приговор. Не говори «поищите сами» — это твоя работа.\n"
        "• Приоритет ОФИЦИАЛЬНЫХ источников над блогами: документация (docs.*, "
        "developer.*, mdn, python.org), наука (pubmed, arxiv, scholar), госисточники "
        "(.gov, nalog.ru, cbr.ru, europa.eu, nih.gov), компании (seller.wildberries.ru, "
        "docs.ozon.ru), энциклопедии (wikipedia, britannica), консультанты (consultant.ru, "
        "garant.ru). При противоречии — верь официальному и честно укажи расхождение.\n"
        "• Фильтруй выдачу: используй ТОЛЬКО реально relevantное. Если пришёл мусор не по "
        "теме — не пересказывай его, скажи «релевантного не нашёл» и переформулируй или "
        "дай ответ из своих знаний (с пометкой). Отличай «упоминание» от «ответа»: если "
        "дословного ответа нет — так и скажи.\n"
        "• Нашёл источники — перечисли их в конце списком «Источники:».\n\n"

        "🛡️ ДОСТОВЕРНОСТЬ И ЧЕСТНОСТЬ (КРИТИЧНО):\n"
        "• 🔴 КРАСНАЯ ЛИНИЯ ПО ПРОВЕРЯЕМЫМ ДАННЫМ (для ЛЮБОЙ темы): конкретное "
        "проверяемое значение — процент (комиссии, тарифы, ставки налогов, штрафы, "
        "лимиты, дозировка), цена, статистика, курс валюты, дата события, имя/должность, "
        "характеристика товара, точная цитата, номер дела/закона/статьи — называть "
        "КОНКРЕТНО можно ТОЛЬКО если в ЭТОМ ЖЕ ответе ты реально вызвал инструмент и "
        "значение есть в его результате. Нет прочитанного источника прямо сейчас — НЕ "
        "называй НИКАКОЕ точное значение, даже примерное, даже «обычно около» или «по "
        "моим данным». Пометка «требует проверки» НЕ легализует выдумку таких данных — "
        "значение просто не приводится. Выдуманный номер дела или статьи закона — опасная "
        "дезинформация, СТРОГО ЗАПРЕЩЕНО.\n"
        "• Что МОЖНО без инструмента: общеизвестные стабильные факты (столица Франции — "
        "Париж, вода кипит при 100 °C, скорость света), общие принципы, объяснения «как "
        "устроено», общие формулировки права («товарные знаки в РФ защищены ГК РФ, "
        "часть 4» + «точную норму уточни у юриста или в КонсультантПлюс»), общие медицинские "
        "знания («при температуре пьют много жидкости» + «к врачу, если хуже»), советы по "
        "стилю/жизни. Чего НЕЛЬЗЯ: свежие/изменчивые цифры (комиссии, цены, курсы, "
        "статистику года, дозировки конкретных препаратов) без проверки.\n"
        "• Вместо выдуманного значения скажи, где его взять. Тарифы маркетплейсов: «Точную "
        "комиссию из головы называть не буду — зависит от категории и модели (FBW/FBS/DBS) "
        "и часто меняется. Смотри в кабинете → Тарифы. Пришли скриншот — разберу». "
        "Налоги — nalog.ru / личный кабинет. Курс валют — cbr.ru / moex. Закон — "
        "consultant.ru / garant.ru. Медицина — к врачу. Прочее — предложи поискать сейчас "
        "(deep_research) или прислать источник/скриншот.\n"
        "• ⚠️ НЕЛЬЗЯ называть значение и рядом ставить источник, который ты НЕ открывал — "
        "это худший вид вранья (выглядит проверенным, но фейк). Источник указывай только "
        "если реально прочитал его инструментом в этом ответе. Пример галлюцинации: "
        "комиссия FBS в парфюмерии WB реально ~33–36% (по кабинету на 2026), а НЕ 17%.\n"
        "• ⚠️ ИЕРАРХИЯ ДОВЕРИЯ К ИСТОЧНИКАМ ЦИФР: личный кабинет/скриншот кабинета и "
        "официальный сайт > блоги/агентства/SEO-статьи. По тарифам, ставкам, ценам блоги "
        "(mpagency, postavleno и т.п.) часто дают УСТАРЕВШИЕ или усреднённые цифры — а "
        "реальные данные в закрытом кабинете поиск прочитать НЕ может. Поэтому если "
        "нашёл цифру только в блоге — НЕ подавай её как факт: пометь «по данным блогов "
        "~X%, но это может быть устаревшим — точное смотри в кабинете/официальном "
        "источнике».\n"
        "• ⚠️ СВЕРЯЙ С УЖЕ ИЗВЕСТНЫМ В ДИАЛОГЕ: если выше в этой беседе уже был более "
        "надёжный источник (скриншот, официальный сайт), а свежий поиск даёт ДРУГУЮ "
        "цифру — НЕ игнорируй конфликт. Опирайся на более надёжный источник и прямо "
        "отметь расхождение: «в блогах ~10–20%, но по твоему скриншоту 33–36% — верь "
        "скриншоту».\n"
        "• 🚫 НИКОГДА не утверждай, что что-то «сделал» (посмотрел сайт, нашёл, проверил, "
        "открыл), если не вызвал инструмент и не получил результат. Просят найти/"
        "посмотреть/проверить → сначала реально вызови инструмент, отвечай только по его "
        "результату. Не сработало/доступа нет/сайт закрыт → честно скажи, что именно не "
        "вышло, и предложи альтернативу (пусть пришлют ссылку/скриншот/файл; или дай "
        "общие знания, ЧЁТКО пометив, что это знания, а не результат проверки). Лучше "
        "честное «вот что удалось, а вот что нет», чем красивая фантазия.\n"
        "• 🧠 НЕ будь угодливым. Если пользователь сообщает факт/цифру, что противоречит "
        "твоим данным или звучит сомнительно — не поддакивай: вежливо отметь расхождение, "
        "по возможности перепроверь инструментом, уточни источник его цифры. Прав — "
        "спокойно согласись без лести. Не хватает данных — скажи «не могу подтвердить или "
        "опровергнуть». Не льсти без причины.\n\n"

        "📋 ФОРМАТ:\n"
        "• 📏 ДЛИНА ОТВЕТА — главное правило: КОРОТКО ПО УМОЛЧАНИЮ, длинно только когда "
        "СПРАШИВАЮТ или это реально нужно. Большинство ответов укладываются в 3-6 строк. "
        "Если в выдаче поиска ничего точного нет — ответ ДОЛЖЕН быть коротким (3-4 строки): "
        "честно сказать «точных данных не нашёл» + где взять + предложение скриншота. "
        "НЕ раздувай ответ структурой ради структуры. Полная развёрнутая структура с "
        "разделами/карточками — ТОЛЬКО когда: (а) пользователь явно просит «подробно/"
        "разверни/обзор/сравни», (б) реально много фактов из инструментов, которые нужно "
        "систематизировать, (в) тема требует пошагового разбора (инструкция, план).\n"
        "• Не делай широкие таблицы (макс. 3-4 коротких колонки, только для коротких "
        "сравнений). Больше данных → формат КАРТОЧЕК: заголовок жирным, под ним список:\n"
        "  **1. Элегантный минимализм**\n"
        "  - Идея: премиальность и чистота\n"
        "  - Палитра: белый, золотой\n"
        "  Это читается в чате лучше громоздкой таблицы.\n"
        "• Длинный ответ разбивай на разделы с markdown-заголовками: `## Название` для "
        "крупных разделов, `### Название` для подразделов. НЕ используй жирный текст "
        "**в начале строки** вместо заголовка — пиши именно `##`. РЕКОМЕНДУЕМАЯ "
        "структура research-ответа (НЕ обязательная, применяй только если ответ реально "
        "объёмный): вводная строка → 1-3 раздела со списками → цифры с источником рядом "
        "→ «Источники:» в конце. Если фактов мало — обойдись обычным абзацем без "
        "заголовков.\n"
        "• ⛔ НЕ ВЫДУМЫВАЙ ДАТЫ И СОБЫТИЯ: фразы типа «последнее обновление — май 2026», "
        "«с апреля 2026 изменилось», «недавно WB повысил тарифы» — это конкретные "
        "проверяемые ФАКТЫ. Если ты не прочитал их прямо сейчас в инструменте — НЕ "
        "называй. Замени на нейтральное «тарифы периодически меняются» или вообще пропусти.\n"
        "• ЯЗЫК: только грамотный русский, без вставок английских слов (используй русские "
        "эквиваленты). Проверяй текст перед ответом.\n\n"

        "💬 ПРИМЕРЫ (как ты отвечаешь в разных случаях):\n"
        "[Пользователь] привет → [Ты] Привет! 🙂 Чем помочь?\n\n"
        "[Пользователь] 2+2? → [Ты] 4 🙂\n\n"
        "[Пользователь] напиши короткое поздравление маме на 60 лет\n"
        "[Ты] (пишешь тёплое, личное, без воды поздравление — БЕЗ инструментов)\n\n"
        "[Пользователь] объясни простыми словами, как работает блокчейн\n"
        "[Ты] (объясняешь на аналогиях — БЕЗ инструментов, это твои знания)\n\n"
        "[Пользователь] какая комиссия Wildberries в парфюмерии по FBS\n"
        "[Ты] (без инструментов) Точный процент из головы называть не стану — зависит от "
        "подкатегории и модели (FBW/FBS/DBS), часто меняется. Самый надёжный источник — "
        "твой кабинет: **WB Партнёры → Финансы → Тарифы → «Комиссия»**, фильтр «Парфюмерия». "
        "Пришли скриншот — разберу. Или поискать сейчас?\n"
        "— (3-4 строки, БЕЗ выдуманных %, БЕЗ фейковых ссылок)\n\n"
        "[Пользователь] найди в интернете актуальную комиссию WB парфюмерия 2026 со ссылками\n"
        "[Ты] (вызвал deep_research, все источники — блоги) В открытом поиске точных "
        "тарифов нет — они в закрытом кабинете продавца. По блогам ориентир FBS ~33–36%, "
        "FBW ~30–35%, но эти цифры могут быть устаревшими. **Точное — только в кабинете**: "
        "seller.wildberries.ru → Тарифы → фильтр «Парфюмерия». Скинешь скриншот — разберу.\n"
        "— (5-6 строк, честно про ограничения, цифры только как ОРИЕНТИР с пометкой)\n\n"
        "[Пользователь] (со скриншотом тарифов) какая у меня комиссия\n"
        "[Ты] (вызвал analyze_image) По твоему скриншоту: FBS парфюмерной воды 36%, FBW "
        "32,5% (категория «Красота»).\n"
        "— (2 строки, цифры точные из скриншота)\n\n"
        "[Пользователь] у меня болит голова уже 3 дня, что делать\n"
        "[Ты] (даёшь нормальный полезный ответ — общие причины, что можно сделать дома, "
        "красные флаги для срочного обращения к врачу. Помечаешь «я не врач», но не "
        "занудствуешь. НЕ называешь дозировки конкретных препаратов без поиска.)\n\n"
        "[Пользователь] какие тренды в нейросетях в 2026 → [Ты] (deep_research → "
        "читаешь источники → структурированный ответ с разделами и «Источники:» в конце)\n\n"
        "[Пользователь] помоги с карточкой товара → [Ты] Конечно! Уточню: 1) что за "
        "товар? 2) что нужно — текст, дизайн, анализ? 🙂\n"
        "— (размытый запрос → сначала уточняешь)\n\n"
        "[Пользователь] посмотри топ-выдачу на Wildberries\n"
        "[Ты] Честно: зайти на WB и посмотреть выдачу напрямую не могу — сайт закрыт "
        "для авто-доступа. Но могу разобрать скриншоты или дать общие принципы. Как "
        "удобнее?\n"
        "— (честно про ограничение + варианты, без выдумки)"
    )


    # Какие модели у каждого OpenAI-совместимого провайдера поддерживают tools.
    # Порядок «умный гибрид» (2026-06-09): топ-качество без VPN первым, потом
    # быстрый Groq (с VPN), потом резервы. Внутри провайдера — от сильной к слабой.
    _FC_PROVIDERS = [
        # 1) Mistral-large — топ-качество, работает БЕЗ VPN. Если ключ есть и лимит цел — лучший выбор.
        ("mistral", ["mistral-large-latest"]),

        # 2) Groq — очень быстрый и щедрый (14 400/день), но требует VPN.
        #    Внутри: от сильной reasoning-модели к более слабым.
        ("groq", [
            "openai/gpt-oss-120b",        # сильная, грамотный русский
            "qwen/qwen3-32b",              # быстрая, хороший русский
            "openai/gpt-oss-20b",          # запасной
            "llama-3.3-70b-versatile",     # llama в конце (бредит про картинки)
        ]),

        # 3) OpenRouter free — резерв на случай «VPN выключен» или Groq упал. ~50/день.
        ("openrouter", [
            "openai/gpt-oss-120b:free",
            "qwen/qwen3-next-80b-a3b-instruct:free",
            "openai/gpt-oss-20b:free",
        ]),

        # 4) Mistral-small — последний шанс без VPN.
        ("mistral", ["mistral-small-latest"]),

        # 5) Cerebras — часто блокирует РФ, поэтому в самом конце.
        ("cerebras", ["llama3.3-70b"]),
    ]

    # Алиасы для команды /model — короткое имя → (провайдер, model_id)
    MODEL_ALIASES = {
        "gpt-oss":   ("groq", "openai/gpt-oss-120b"),
        "llama":     ("groq", "llama-3.3-70b-versatile"),
        "fast":      ("groq", "llama-3.1-8b-instant"),
        "gemini":    ("google", None),
        "qwen":      ("openrouter", "qwen/qwen3-next-80b-a3b-instruct:free"),
    }

    def _run_via_openai_compat(self, msg: str, max_turns: int = 6,
                                prior_messages: list[dict] | None = None) -> str | None:
        """
        Шаг 2 Фазы 3: prior_messages — честная история прошлых turn-ов в OpenAI-формате
        (без system, без текущего user). Если передана — модель видит свои прошлые
        tool_calls и не повторяет analyze_image впустую / не выдумывает.
        Если None — работает по-старому (только текущее сообщение).
        """
        providers_list = self._FC_PROVIDERS
        # Если задана принудительная модель — используем только её
        if self.force_model and self.force_model in self.MODEL_ALIASES:
            pn, mid = self.MODEL_ALIASES[self.force_model]
            if pn != "google" and mid:
                providers_list = [(pn, [mid])]
            else:
                providers_list = []  # google обрабатывается отдельной веткой
        # Авто-режим: если на сессию уже закреплена рабочая модель — пробуем ЕЁ первой
        # (стабильность: одна модель ведёт весь диалог, без прыжков между сообщениями).
        elif self.session_model:
            sp, sm = self.session_model
            if sp != "google":
                rest = [(p, ms) for (p, ms) in self._FC_PROVIDERS]
                providers_list = [(sp, [sm])] + rest

        # Базовая часть сообщений: system + история прошлых turn-ов (если передана)
        base_msgs = [{"role": "system", "content": self.SYS_PROMPT}]
        if prior_messages:
            # Защита: не пускаем system из истории (мог попасть случайно)
            base_msgs.extend([m for m in prior_messages if m.get("role") != "system"])

        for prov_name, fc_models in providers_list:
            prov = self.pg.providers.get(prov_name)
            if not prov or not prov.ok:
                continue

            for model_id in fc_models:
                msgs = base_msgs + [{"role": "user", "content": msg}]
                for _ in range(max_turns):
                    try:
                        kw = dict(model=model_id, messages=msgs, max_tokens=2048)
                        if self.tools:
                            kw["tools"] = self._tools_schema()
                            kw["tool_choice"] = "auto"

                        r = prov.c.chat.completions.create(**kw)
                        m = r.choices[0].message

                        if m.tool_calls:
                            tcs = [{"id": tc.id, "type": "function",
                                    "function": {"name": tc.function.name,
                                                 "arguments": tc.function.arguments}}
                                   for tc in m.tool_calls]
                            msgs.append({"role": "assistant", "content": m.content or "", "tool_calls": tcs})
                            for tc in m.tool_calls:
                                try:
                                    args = json.loads(tc.function.arguments or "{}")
                                except Exception:
                                    args = {}
                                result = self._execute_tool(tc.function.name, args)
                                if self.debug:
                                    print(f"   [{prov_name} tool] {tc.function.name}({args}) -> {result[:120]}")
                                msgs.append({"role": "tool", "tool_call_id": tc.id, "content": result})
                        else:
                            self.last_model = f"{prov_name}/{model_id}"
                            # Закрепляем рабочую модель на сессию (только в авто-режиме).
                            # ⚠️ ВАЖНО: ВСЕГДА перезаписываем session_model текущей моделью —
                            # это автоматически чинит W4 (если закреплённая модель упала и
                            # вызвалась запасная, теперь запасная и станет новой закреплённой).
                            if not self.force_model:
                                self.session_model = (prov_name, model_id)
                            # Нормализуем content: некоторые провайдеры (Mistral) возвращают
                            # его не строкой, а списком [{"type":"text","text":"..."}] —
                            # это валидный OpenAI-формат, но re.sub на нём падает.
                            raw_content = m.content
                            if isinstance(raw_content, list):
                                parts_text = []
                                for p in raw_content:
                                    if isinstance(p, dict):
                                        # OpenAI-стиль: {"type":"text","text":"..."}
                                        parts_text.append(p.get("text", "") or "")
                                    elif isinstance(p, str):
                                        parts_text.append(p)
                                    else:
                                        # Возможно объект с .text атрибутом (Mistral SDK)
                                        parts_text.append(str(getattr(p, "text", p) or ""))
                                final_text = "".join(parts_text) or "[no response]"
                            else:
                                final_text = raw_content or "[no response]"
                            msgs.append({"role": "assistant", "content": final_text})
                            # Лог turn-а БЕЗ системного промпта и без истории прошлых turn-ов
                            # (сохраняем только то, что ДОБАВИЛОСЬ в этом turn-е).
                            base_len = len(base_msgs)
                            self.last_messages = msgs[base_len:]
                            return final_text
                    except Exception as e:
                        if self.debug:
                            print(f"   [{prov_name} {model_id} error] {type(e).__name__}: {str(e)[:120]}")
                        break  # эта модель не сработала — следующая

        # Все модели перебраны и ни одна не ответила.
        # Если была закреплённая модель — сбрасываем её, чтобы следующий вызов
        # не начинал снова с заведомо упавшей (W4: лишний фейл-цикл на каждом сообщении).
        if not self.force_model and self.session_model:
            if self.debug:
                print(f"   [reset] session_model {self.session_model} сброшен (все упали)")
            self.session_model = None
        return None

    def run(self, msg: str, max_turns: int = 8,
            prior_messages: list[dict] | None = None) -> str:
        """
        prior_messages (Шаг 2 Фазы 3) — честная история ПРОШЛЫХ turn-ов в OpenAI-формате:
        [{"role":"user","content":...}, {"role":"assistant","content":..., "tool_calls":[...]},
         {"role":"tool","tool_call_id":..., "content":...}, ...].
        Если передана — модель видит свои прошлые вызовы инструментов и не выдумывает.
        Если None — работает как раньше (только текущее сообщение, без памяти диалога).
        ВАЖНО: текущее `msg` подставляется ОТДЕЛЬНО и не должно входить в prior_messages.
        """
        # Сбрасываем лог сообщений — наполнится текущим turn-ом внутри _run_via_*
        self.last_messages = []
        import re as _re
        IMG_RE = r'https?://\S+\.(?:jpg|jpeg|png|webp|gif|bmp)(?:\?\S*)?'

        # Находим все ссылки на картинки во всём сообщении (включая историю диалога).
        img_urls = _re.findall(IMG_RE, msg, _re.I)
        # Признак, что пользователь говорит про изображение
        wants_image = bool(_re.search(r'(?i)(картинк|изображени|фото|снимок|скрин|опиши.*(её|ее|это)|на ней|на нём|на нем)', msg))

        # YouTube-ссылки: модели часто отказываются от инструмента «я не могу»,
        # хотя watch_youtube есть. Жёстко напоминаем (как для картинок).
        YT_RE = r'https?://(?:www\.|m\.)?(?:youtube\.com/(?:watch\?\S*v=|shorts/|embed/)|youtu\.be/)[A-Za-z0-9_-]{11}\S*'
        yt_urls = _re.findall(YT_RE, msg, _re.I)
        if yt_urls:
            last_yt = yt_urls[-1]
            msg = msg + (f"\n\n[Система: в сообщении ссылка на YouTube: {last_yt}. "
                         f"ОБЯЗАТЕЛЬНО вызови инструмент watch_youtube с url='{last_yt}'. "
                         f"ЗАПРЕЩЕНО отвечать «не могу», «нет доступа», «установи библиотеку» — "
                         f"инструмент УЖЕ есть и работает. Если субтитры реально недоступны "
                         f"(инструмент вернёт ошибку) — только тогда честно сообщи об этом.]")

        if img_urls:
            # Берём ПОСЛЕДНЮЮ упомянутую ссылку на картинку (самую свежую в диалоге)
            last_img = img_urls[-1]
            msg = msg + (f"\n\n[Система: в диалоге есть изображение: {last_img}\n"
                         f"Если пользователь просит описать/проанализировать картинку — "
                         f"ОБЯЗАТЕЛЬНО вызови инструмент analyze_image с url='{last_img}'. "
                         f"НЕ придумывай содержимое по названию файла — посмотри реально через инструмент.]")
        elif wants_image:
            msg = msg + ("\n\n[Система: пользователь спрашивает про изображение, но прямой ссылки нет. "
                         "Посмотри выше в диалоге — возможно, ссылка была в предыдущих сообщениях. "
                         "Если нашёл — вызови analyze_image. Если ссылки нигде нет — попроси прислать её.]")


        # Для картинок Gemini надёжнее (видит изображения нативно) — пробуем его ПЕРВЫМ,
        # даже если выбрана другая модель.
        # Шаг 3 Фазы 3: теперь передаём prior_messages — Gemini тоже видит честную историю.
        if (img_urls or wants_image) and self.force_model != "gemini":
            gprov = self.pg.providers.get("google")
            if gprov and gprov.ok:
                result = self._run_via_google(msg, max_turns, prior_messages=prior_messages)
                if result is not None:
                    return result

        # Если принудительно выбран Gemini — сначала пробуем его
        if self.force_model == "gemini":
            result = self._run_via_google(msg, max_turns, prior_messages=prior_messages)
            if result is not None:
                return result

        # 1. OpenAI-совместимые провайдеры: Mistral → Groq → OpenRouter → ...
        #    Передаём prior_messages (если есть) — это включает «честную память диалога».
        result = self._run_via_openai_compat(msg, max_turns, prior_messages=prior_messages)
        if result is not None:
            return result

        # 2. Google Gemini (нативный function calling) — как резерв
        result = self._run_via_google(msg, max_turns, prior_messages=prior_messages)
        if result is not None:
            return result

        # 3. Fallback: ответ без инструментов через роутинг
        self.last_model = "fallback/route"
        return self.pg.route(msg)



# ===== Стандартные инструменты =====

def default_tools(tavily_key: str = "", workdir: str = "agent_files", allow_exec: bool = True) -> list[Tool]:
    import subprocess, sys, urllib.parse, urllib.request

    os.makedirs(workdir, exist_ok=True)

    def _safe_path(path: str) -> str:
        """Не даём вырваться за пределы рабочей папки агента."""
        full = os.path.abspath(os.path.join(workdir, path))
        base = os.path.abspath(workdir)
        if not full.startswith(base):
            raise ValueError("путь вне рабочей папки запрещён")
        return full

    def search(query: str) -> str:
        # 1) Tavily (если есть ключ) — самый качественный поиск для AI
        if tavily_key:
            try:
                import requests
                r = requests.post("https://api.tavily.com/search",
                    json={"api_key": tavily_key, "query": query,
                          "search_depth": "advanced", "max_results": 6,
                          "include_answer": True}, timeout=20)
                data = r.json()
                parts = []
                if data.get("answer"):
                    # ⚠️ ВАЖНО: Tavily-сводка — это AI-резюме топ-выдачи поиска (включая блоги).
                    # Часто врёт на тарифах/ценах/цифрах (HOTFIX 2026-06-09: словили выдумку
                    # «комиссия WB парфюмерия 17%», когда реально по кабинету ~33-36%).
                    # Помечаем явно — модель в промпте знает: цифры только из РЕАЛЬНО
                    # прочитанных источников, а не из сводки.
                    parts.append(
                        f"⚠️ AI-СВОДКА TAVILY (это резюме топ-выдачи поиска, включая блоги; "
                        f"может содержать УСТАРЕВШИЕ или ВЫДУМАННЫЕ цифры — НЕ цитируй цифры "
                        f"из этой сводки без проверки на оригинальной странице): {data['answer']}"
                    )
                for it in data.get("results", [])[:6]:
                    parts.append(f"- {it.get('title','')} ({it.get('url','')}): "
                                 f"{it.get('content','')[:300]}")
                if parts:
                    return "\n".join(parts)
            except Exception:
                pass

        out = []
        # 2) DuckDuckGo Instant Answer — хорош для определений/фактов
        try:
            url = "https://api.duckduckgo.com/?q=" + urllib.parse.quote(query) + "&format=json&no_html=1"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            data = json.loads(urllib.request.urlopen(req, timeout=12).read().decode("utf-8", "ignore"))
            if data.get("AbstractText"):
                out.append(f"- {data.get('Heading','')}: {data['AbstractText']}")
            for t in data.get("RelatedTopics", [])[:4]:
                if isinstance(t, dict) and t.get("Text"):
                    out.append(f"- {t['Text']}")
        except Exception:
            pass

        # 3) Wikipedia (ru) — надёжный бесплатный источник без ключа
        if len(out) < 3:
            try:
                import re as _re
                wurl = "https://ru.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
                    "action":"query","list":"search","srsearch":query,
                    "format":"json","srlimit":5,
                })
                wreq = urllib.request.Request(wurl, headers={"User-Agent":"Polygraph/1.0"})
                wdata = json.loads(urllib.request.urlopen(wreq, timeout=12).read().decode("utf-8","ignore"))
                for it in wdata.get("query",{}).get("search",[]):
                    snip = _re.sub(r"<[^>]+>", "", it.get("snippet",""))
                    out.append(f"- {it.get('title','')}: {snip}")
            except Exception:
                pass

        if out:
            # убираем дубли, ограничиваем
            seen, uniq = set(), []
            for line in out:
                if line not in seen:
                    seen.add(line); uniq.append(line)
            return "\n".join(uniq[:8])
        return (f"[поиск '{query}'] — ничего не найдено. Совет: используй fetch_url "
                f"с конкретной ссылкой, либо задай TAVILY_API_KEY для лучшего поиска.")

    def calc(expression: str) -> str:
        try:
            return str(eval(expression, {"__builtins__":{}}, {
                "abs":abs,"round":round,"min":min,"max":max,"pow":pow,"sum":sum,"len":len}))
        except Exception as e:
            return f"ошибка: {e}"

    def read_file(path: str, pages: str = "") -> str:
        """
        Чтение файлов (текст, PDF, Excel, CSV).
        pages — для PDF: диапазон страниц (Фаза 4):
          "" (по умолчанию) → первые 30 страниц
          "1-10" → страницы 1..10 (включительно)
          "5-5" или "5" → только страница 5
          "last10" → последние 10 страниц
          "all" → все страницы (внимание: большой PDF съест много контекста)
        """
        try:
            full = _safe_path(path)
            if not os.path.exists(full):
                return f"[файл не найден: {path}]"
            # PDF — извлекаем текст (если установлен pypdf)
            if full.lower().endswith(".pdf"):
                try:
                    from pypdf import PdfReader
                    reader = PdfReader(full)
                    total = len(reader.pages)
                    # Парсим pages → список индексов (0-based)
                    pg_list: list[int] = []
                    p = (pages or "").strip().lower()
                    if not p:
                        pg_list = list(range(min(30, total)))
                    elif p == "all":
                        pg_list = list(range(total))
                    elif p.startswith("last"):
                        try:
                            n = int(p[4:])
                            pg_list = list(range(max(0, total - n), total))
                        except ValueError:
                            pg_list = list(range(min(30, total)))
                    elif "-" in p:
                        try:
                            a, b = p.split("-", 1)
                            a, b = int(a), int(b)
                            pg_list = list(range(max(0, a - 1), min(total, b)))
                        except ValueError:
                            pg_list = list(range(min(30, total)))
                    else:
                        try:
                            n = int(p) - 1
                            if 0 <= n < total:
                                pg_list = [n]
                            else:
                                return f"[стр. {p} вне диапазона: всего страниц {total}]"
                        except ValueError:
                            pg_list = list(range(min(30, total)))

                    text_parts = []
                    for idx in pg_list:
                        t = reader.pages[idx].extract_text() or ""
                        if t.strip():
                            text_parts.append(f"--- стр. {idx+1} ---\n{t}")
                    text = "\n".join(text_parts)

                    if not text.strip():
                        return (f"[PDF '{path}' открыт, всего {total} стр., но текст не "
                                f"извлёкся — возможно, это скан-картинки. Попробуй "
                                f"`analyze_image` для конкретных страниц или search_pdf для поиска.]")

                    # Лимит увеличен до 25К (было 8К) — для длинных договоров/отчётов
                    LIMIT = 25000
                    if len(text) > LIMIT:
                        text = text[:LIMIT] + f"\n\n[... обрезано на {LIMIT} символах; всего в PDF {total} стр., запрошены {len(pg_list)} стр. Хочешь — укажи pages='X-Y' для другого диапазона]"
                    # Подсказка пользователю про навигацию
                    if not pages and total > 30:
                        text += f"\n\n[Подсказка: показаны стр. 1-30 из {total}. Для остальных вызови read_file(path, pages='31-60') или pages='last10']"
                    return text
                except ImportError:
                    return "[для чтения PDF установи библиотеку: pip install pypdf]"
                except Exception as e:
                    return f"[ошибка чтения PDF: {e}]"
            # Excel (.xlsx / .xls) — извлекаем таблицу как текст
            if full.lower().endswith((".xlsx", ".xls", ".xlsm")):
                try:
                    from openpyxl import load_workbook
                    wb = load_workbook(full, read_only=True, data_only=True)
                    out = []
                    for ws in wb.worksheets[:5]:
                        out.append(f"=== Лист: {ws.title} ===")
                        rows = 0
                        for row in ws.iter_rows(values_only=True):
                            cells = ["" if c is None else str(c) for c in row]
                            if any(cells):
                                out.append(" | ".join(cells))
                                rows += 1
                            if rows >= 200:
                                out.append("... (показаны первые 200 строк)")
                                break
                    txt = "\n".join(out)
                    return txt[:8000] if txt.strip() else "[Excel-файл пуст]"
                except ImportError:
                    return "[для чтения Excel установи: pip install openpyxl]"
                except Exception as e:
                    return f"[ошибка чтения Excel: {e}]"
            # CSV — читаем как таблицу
            if full.lower().endswith(".csv"):
                try:
                    import csv as _csv
                    out = []
                    for enc in ("utf-8-sig", "cp1251", "utf-8"):
                        try:
                            with open(full, "r", encoding=enc, newline="") as f:
                                sample = f.read(2048); f.seek(0)
                                delim = ";" if sample.count(";") > sample.count(",") else ","
                                reader = _csv.reader(f, delimiter=delim)
                                for i, row in enumerate(reader):
                                    out.append(" | ".join(row))
                                    if i >= 200:
                                        out.append("... (первые 200 строк)")
                                        break
                            break
                        except UnicodeDecodeError:
                            out = []; continue
                    txt = "\n".join(out)
                    return txt[:8000] if txt.strip() else "[CSV пуст]"
                except Exception as e:
                    return f"[ошибка чтения CSV: {e}]"
            # Обычный текстовый файл
            with open(full, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            return content[:8000] if content else "[файл пуст]"
        except Exception as e:
            return f"[ошибка чтения: {e}]"

    def search_pdf(path: str, query: str, context: int = 200) -> str:
        """
        Поиск ключевого слова/фразы по всему PDF (Фаза 4).
        Возвращает фрагменты с контекстом и номерами страниц.
        Полезно для длинных документов (договоры, отчёты, инструкции).
        """
        try:
            full = _safe_path(path)
            if not os.path.exists(full):
                return f"[файл не найден: {path}]"
            if not full.lower().endswith(".pdf"):
                return "[search_pdf работает только с PDF-файлами]"
            try:
                from pypdf import PdfReader
            except ImportError:
                return "[для PDF установи: pip install pypdf]"
            reader = PdfReader(full)
            total = len(reader.pages)
            q = (query or "").strip().lower()
            if not q:
                return "[пустой поисковый запрос]"
            findings = []
            for i, page in enumerate(reader.pages):
                t = page.extract_text() or ""
                tl = t.lower()
                start = 0
                while True:
                    pos = tl.find(q, start)
                    if pos < 0:
                        break
                    a = max(0, pos - context)
                    b = min(len(t), pos + len(q) + context)
                    snippet = t[a:b].strip().replace("\n", " ")
                    # выделяем найденное жирным
                    findings.append(f"--- стр. {i+1} ---\n...{snippet}...")
                    start = pos + len(q)
                    if len(findings) >= 20:  # лимит, чтобы не раздуть ответ
                        break
                if len(findings) >= 20:
                    break
            if not findings:
                return (f"[в PDF '{path}' ({total} стр.) фраза '{query}' не найдена. "
                        f"Попробуй синонимы или прочитай конкретный диапазон через read_file(pages='X-Y')]")
            head = f"Найдено {len(findings)} совпадений по запросу '{query}' в PDF '{path}' ({total} стр.):\n\n"
            return head + "\n\n".join(findings)
        except Exception as e:
            return f"[ошибка search_pdf: {e}]"

    def write_file(path: str, content: str) -> str:
        try:
            p = _safe_path(path)
            os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(content)
            return f"[записано {len(content)} символов в {path}]"
        except Exception as e:
            return f"[ошибка записи: {e}]"

    def list_files(path: str = ".") -> str:
        try:
            base = _safe_path(path)
            items = []
            for name in sorted(os.listdir(base)):
                full = os.path.join(base, name)
                size = os.path.getsize(full) if os.path.isfile(full) else "-"
                items.append(f"{'DIR ' if os.path.isdir(full) else 'FILE'} {name} ({size})")
            return "\n".join(items) or "[папка пуста]"
        except Exception as e:
            return f"[ошибка: {e}]"

    def run_python(code: str) -> str:
        """Выполнить Python-код в подпроцессе (внутри рабочей папки)."""
        try:
            r = subprocess.run([sys.executable, "-c", code], capture_output=True,
                               text=True, timeout=20, cwd=workdir)
            out = (r.stdout or "")[:4000]
            err = (r.stderr or "")[:2000]
            res = ""
            if out: res += f"STDOUT:\n{out}"
            if err: res += f"\nSTDERR:\n{err}"
            return res.strip() or "[код выполнен, вывода нет]"
        except subprocess.TimeoutExpired:
            return "[ошибка: превышено время выполнения 20с]"
        except Exception as e:
            return f"[ошибка выполнения: {e}]"

    def fetch_url(url: str) -> str:
        """Скачать веб-страницу и вернуть её текст (HTML → чистый текст)."""
        import re, html as html_mod
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        # Кодируем не-ASCII символы в URL (кириллица в адресе и т.п.)
        try:
            url = urllib.parse.quote(url, safe=":/?#[]@!$&'()*+,;=%~")
        except Exception:
            pass
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/120.0 Safari/537.36",
                "Accept-Language": "ru,en;q=0.9",
            })
            raw = urllib.request.urlopen(req, timeout=20).read()
            # Если это PDF (по сигнатуре или расширению) — извлекаем текст через pypdf
            if raw[:5] == b"%PDF-" or url.lower().split("?")[0].endswith(".pdf"):
                try:
                    from pypdf import PdfReader
                    import io as _io
                    reader = PdfReader(_io.BytesIO(raw))
                    pdftext = "\n".join((page.extract_text() or "") for page in reader.pages[:40])
                    if pdftext.strip():
                        return pdftext[:9000]
                    return f"[PDF по ссылке {url} открыт, но текст не извлёкся (возможно, скан-картинки)]"
                except ImportError:
                    return "[для чтения PDF установи: pip install pypdf]"
                except Exception as e:
                    return f"[ошибка чтения PDF: {e}]"
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                text = raw.decode("cp1251", "ignore")
        except Exception as e:
            return f"[не удалось открыть {url}: {e}]"

        # Удаляем скрипты/стили/теги, превращаем в читаемый текст
        text = re.sub(r"(?is)<(script|style|noscript|svg|head|nav|header|footer|aside|form|button|select).*?</\1>", " ", text)
        # Вырезаем типовые блоки навигации/меню по id/class
        text = re.sub(r'(?is)<(div|ul|section)[^>]*(id|class)="[^"]*(nav|menu|sidebar|footer|header|banner|cookie|lang)[^"]*"[^>]*>.*?</\1>', " ", text)
        text = re.sub(r"(?is)<br\s*/?>", "\n", text)
        text = re.sub(r"(?is)</(p|div|li|tr|h[1-6])>", "\n", text)
        text = re.sub(r"(?is)<[^>]+>", " ", text)            # остальные теги
        text = html_mod.unescape(text)                        # &amp; → &
        # Подчищаем вики-разметку, если попалась: [[ссылка|текст]] → текст, <ref>…</ref> → ''
        text = re.sub(r"(?is)<ref[^>]*>.*?</ref>", "", text)
        text = re.sub(r"(?is)<ref[^>]*/>", "", text)
        text = re.sub(r"\[\[(?:[^\]|]*\|)?([^\]]+)\]\]", r"\1", text)
        text = re.sub(r"\{\{[^}]*\}\}", "", text)
        text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
        text = re.sub(r"[ \t]+", " ", text)

        # Оставляем содержательные строки: длинные ИЛИ с точкой/двоеточием.
        # Это отсекает списки коротких ссылок (меню, список языков и т.п.).
        good_lines = []
        for ln in text.split("\n"):
            s = ln.strip()
            if not s:
                continue
            if len(s) >= 40 or s.endswith((".", ":", "!", "?")) or s.count(" ") >= 6:
                good_lines.append(s)
        text = "\n".join(good_lines)
        text = re.sub(r"\n\s*\n+", "\n\n", text).strip()
        if not text:
            return f"[страница {url} открыта, но текст не извлёкся (возможно, JS-сайт)]"
        return text[:6000]  # ограничиваем, чтобы влезло в контекст модели

    def analyze_pdf_page(path: str, page: int = 1, question: str = "Опиши, что на этой странице.") -> str:
        """
        Vision-fallback для PDF (Фаза 4): рендерит ОДНУ страницу PDF в картинку
        и отправляет в analyze_image (Gemini Vision).
        Используй ТОЛЬКО если read_file('doc.pdf') вернул "[PDF без извлекаемого текста]"
        — это значит, что PDF из сканов/картинок, и обычный текст не работает.

        ⚠️ Дорого по токенам (~1000 на страницу) — НЕ используй на большом PDF, только
        на отдельных страницах. Для текстовых PDF всегда предпочитай read_file.
        """
        try:
            full = _safe_path(path)
            if not os.path.exists(full):
                return f"[файл не найден: {path}]"
            if not full.lower().endswith(".pdf"):
                return "[analyze_pdf_page работает только с PDF]"
            try:
                from pypdf import PdfReader
            except ImportError:
                return "[установи: pip install pypdf]"
            # Пробуем рендерить через pdf2image (нужен poppler) или pypdf+pillow
            try:
                from pdf2image import convert_from_path
                images = convert_from_path(full, dpi=150, first_page=page, last_page=page)
                if not images:
                    return f"[стр. {page} не найдена]"
                img = images[0]
            except ImportError:
                return ("[для рендера сканированных PDF установи: pip install pdf2image "
                        "+ системно poppler (Windows: choco install poppler). "
                        "Альтернатива: открой PDF, сделай скриншот нужной страницы и пришли как картинку.]")
            except Exception as e:
                return f"[ошибка рендера PDF-страницы: {e}]"

            # Сохраняем во временную картинку в gen-папке и вызываем analyze_image
            import time as _t
            tmpdir = os.path.join(workdir, "generated")
            os.makedirs(tmpdir, exist_ok=True)
            tmppath = os.path.join(tmpdir, f"pdf_page_{int(_t.time())}_{page}.png")
            img.save(tmppath, "PNG")
            rel = os.path.relpath(tmppath, workdir).replace("\\", "/")
            return analyze_image(rel, question)
        except Exception as e:
            return f"[ошибка analyze_pdf_page: {e}]"

    def watch_youtube(url: str, language: str = "ru") -> str:
        """
        Читает субтитры YouTube-видео и возвращает текст с тайм-кодами (Фаза 4).
        В 200+ раз дешевле, чем Vision API на кадрах.
        Работает с любым публичным видео, у которого есть субтитры
        (ручные или авто-сгенерированные YouTube'ом).

        url: ссылка на видео (youtube.com/watch?v=..., youtu.be/..., /shorts/...)
        language: предпочитаемый язык субтитров ('ru' по умолчанию).
                  Если на этом языке нет — попробует en и автодоступные.
        """
        import re as _re
        # 1. Извлекаем video_id из URL
        patterns = [
            r"(?:youtube\.com/watch\?(?:.*&)?v=|youtu\.be/|youtube\.com/shorts/|youtube\.com/embed/)([A-Za-z0-9_-]{11})",
            r"^([A-Za-z0-9_-]{11})$",  # если передан уже сам ID
        ]
        video_id = None
        for pat in patterns:
            m = _re.search(pat, url)
            if m:
                video_id = m.group(1)
                break
        if not video_id:
            return f"[не удалось извлечь video_id из URL '{url}'. Ожидаю youtube.com/watch?v=... или youtu.be/...]"

        # API библиотеки СМЕНИЛСЯ в версии 1.x (2026):
        # старый YouTubeTranscriptApi.get_transcript() удалён → теперь api = YouTubeTranscriptApi(); api.fetch()
        # старый list_transcripts() → теперь api.list()
        # снippet'ы теперь объекты с атрибутами .text/.start/.duration, а не dict-ы
        try:
            from youtube_transcript_api import (
                YouTubeTranscriptApi, TranscriptsDisabled, NoTranscriptFound,
                VideoUnavailable, IpBlocked, RequestBlocked,
            )
        except ImportError:
            return "[для чтения YouTube установи: pip install youtube-transcript-api]"

        api = YouTubeTranscriptApi()

        # 2. Пробуем языки по приоритету: пользовательский → ru → en → любой
        lang_priorities = [language, "ru", "en"]
        seen = set()
        lang_priorities = [l for l in lang_priorities if not (l in seen or seen.add(l))]

        fetched = None  # FetchedTranscript
        used_lang = None
        last_err = None

        # Сначала прямые попытки по конкретным языкам
        for lang in lang_priorities:
            try:
                fetched = api.fetch(video_id, languages=[lang])
                used_lang = getattr(fetched, "language_code", lang)
                break
            except (TranscriptsDisabled, NoTranscriptFound) as e:
                last_err = e
                continue
            except (IpBlocked, RequestBlocked) as e:
                return (f"[YouTube заблокировал запрос ({type(e).__name__}). Возможно, "
                        f"слишком много запросов или IP в чёрном списке. Попробуй позже, "
                        f"с VPN, или другое видео.]")
            except VideoUnavailable:
                return f"[видео {video_id} недоступно (приватное, удалено или заблокировано в твоём регионе)]"
            except Exception as e:
                last_err = e
                continue

        # Если по конкретным языкам не вышло — берём любой доступный через list()
        if not fetched:
            try:
                tl = api.list(video_id)
                for t in tl:  # Transcript объекты
                    try:
                        fetched = t.fetch()
                        used_lang = getattr(t, "language_code", "?")
                        break
                    except Exception:
                        continue
            except (TranscriptsDisabled, NoTranscriptFound):
                return (f"[у видео {video_id} нет субтитров (ни ручных, ни авто). "
                        f"Возможно это live, приватное или новая загрузка без авто-субтитров.]")
            except (IpBlocked, RequestBlocked):
                return (f"[YouTube заблокировал запрос. Попробуй позже или с VPN.]")
            except VideoUnavailable:
                return f"[видео {video_id} недоступно]"
            except Exception as e:
                last_err = e

        if not fetched:
            err_name = type(last_err).__name__ if last_err else "неизвестная ошибка"
            err_msg = str(last_err)[:200] if last_err else ""
            return (f"[не удалось получить субтитры для {video_id}: {err_name}"
                    + (f" — {err_msg}" if err_msg else "")
                    + ". Возможно, у видео нет субтитров или YouTube временно недоступен.]")

        # 3. Форматируем с тайм-кодами
        def fmt_ts(seconds: float) -> str:
            s = int(seconds)
            h, rem = divmod(s, 3600)
            m, s = divmod(rem, 60)
            return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"

        lines = []
        full_chars = 0
        LIMIT = 20000  # ~5000 токенов, для часовых видео хватает
        truncated = False
        # FetchedTranscript итерируется и даёт FetchedTranscriptSnippet (.text, .start, .duration)
        for snippet in fetched:
            ts = fmt_ts(getattr(snippet, "start", 0) or 0)
            txt = (getattr(snippet, "text", "") or "").replace("\n", " ").strip()
            if not txt:
                continue
            line = f"[{ts}] {txt}"
            if full_chars + len(line) > LIMIT:
                truncated = True
                break
            lines.append(line)
            full_chars += len(line) + 1

        if not lines:
            return f"[субтитры видео {video_id} пустые]"

        header = f"📺 Субтитры YouTube ({video_id}, язык: {used_lang})"
        if truncated:
            header += f" — показано первые {len(lines)} строк, видео длинное"
        return header + ":\n\n" + "\n".join(lines)

    def analyze_image(image: str, question: str = "Опиши подробно, что на этом изображении.") -> str:
        """Проанализировать изображение (путь к файлу в рабочей папке или URL).
        Использует Gemini (vision) или vision-модель OpenRouter."""
        import base64, urllib.request as _u

        # Получаем байты картинки + mime
        img_bytes, mime = None, "image/jpeg"
        try:
            if image.startswith(("http://", "https://")):
                req = _u.Request(image, headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                                  "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    "Accept": "image/avif,image/webp,image/png,image/jpeg,image/*,*/*;q=0.8",
                    "Referer": "https://www.google.com/",
                })
                img_bytes = _u.urlopen(req, timeout=20).read()
                if image.lower().endswith(".png"): mime = "image/png"
                elif image.lower().endswith((".webp",)): mime = "image/webp"
            else:
                p = _safe_path(image)
                if not os.path.exists(p):
                    return f"[изображение не найдено: {image}]"
                with open(p, "rb") as f:
                    img_bytes = f.read()
                if p.lower().endswith(".png"): mime = "image/png"
                elif p.lower().endswith(".webp"): mime = "image/webp"
        except Exception as e:
            return (f"ОШИБКА ЗАГРУЗКИ ИЗОБРАЖЕНИЯ ({e}). "
                    f"Сообщи пользователю ЧЕСТНО: картинку по этой ссылке скачать не удалось "
                    f"(возможно, сайт блокирует доступ). НЕ ПРИДУМЫВАЙ, что на ней изображено — "
                    f"ты её НЕ видел. Попроси прислать другую ссылку или загрузить файл.")

        if not img_bytes:
            return "[пустое изображение]"

        # Определяем MIME по сигнатуре файла (надёжнее, чем по расширению URL)
        if img_bytes[:3] == b"\xff\xd8\xff":
            mime = "image/jpeg"
        elif img_bytes[:8] == b"\x89PNG\r\n\x1a\n":
            mime = "image/png"
        elif img_bytes[:4] == b"RIFF" and img_bytes[8:12] == b"WEBP":
            mime = "image/webp"
        elif img_bytes[:6] in (b"GIF87a", b"GIF89a"):
            mime = "image/gif"

        # 1) Пробуем Gemini (нативный vision). Несколько моделей — у каждой свой лимит.
        gkey = os.environ.get("GEMINI_API_KEY", "")
        if gkey:
            try:
                from google import genai
                from google.genai import types as gt
                client = genai.Client(api_key=gkey)
                for gmodel in ("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-pro"):
                    try:
                        resp = client.models.generate_content(
                            model=gmodel,
                            contents=[
                                gt.Part.from_bytes(data=img_bytes, mime_type=mime),
                                question,
                            ],
                        )
                        if resp and getattr(resp, "text", None):
                            return resp.text
                    except Exception:
                        continue
            except Exception:
                pass

        # 2) OpenRouter vision (qwen2.5-vl free)
        okey = os.environ.get("OPENROUTER_API_KEY", "")
        if okey:
            try:
                from openai import OpenAI
                client = OpenAI(api_key=okey, base_url="https://openrouter.ai/api/v1")
                b64 = base64.b64encode(img_bytes).decode()
                for vmodel in ("google/gemma-4-31b-it:free",
                               "google/gemma-4-26b-a4b-it:free",
                               "nvidia/nemotron-nano-12b-v2-vl:free",
                               "moonshotai/kimi-k2.6:free"):
                    try:
                        r = client.chat.completions.create(
                            model=vmodel,
                            messages=[{"role": "user", "content": [
                                {"type": "text", "text": question},
                                {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}},
                            ]}],
                            max_tokens=1024, timeout=40)
                        c = r.choices[0].message.content
                        if c:
                            return c
                    except Exception:
                        continue
            except Exception:
                pass

        return ("Не получилось проанализировать изображение прямо сейчас — vision-модели "
                "(Gemini / OpenRouter) недоступны: вероятно, исчерпан дневной лимит или "
                "провайдер занят. Сообщи это пользователю ЧЕСТНО и предложи попробовать "
                "чуть позже. НЕ придумывай содержимое картинки.")

    def generate_image(prompt: str) -> str:
        """Генерация изображения. Gemini (nano-banana) → Cloudflare FLUX как запаска.
        Возвращает маркер IMAGE: для показа в чате."""
        import time as _t, base64 as _b64
        gendir = os.path.join(workdir, "generated")
        os.makedirs(gendir, exist_ok=True)
        fname = f"img_{int(_t.time())}.png"
        fpath = os.path.join(gendir, fname)
        rel = os.path.join("generated", fname).replace("\\", "/")
        errors = []

        # 1) Gemini (nano-banana) — ~500/день бесплатно, нужен VPN
        gkey = os.environ.get("GEMINI_API_KEY", "")
        if gkey:
            try:
                from google import genai
                from google.genai import types as gt
                client = genai.Client(api_key=gkey)
                try:
                    resp = client.models.generate_content(
                        model="gemini-2.5-flash-image", contents=prompt,
                        config=gt.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
                    )
                    parts = resp.candidates[0].content.parts if resp.candidates else []
                    for part in parts:
                        if getattr(part, "inline_data", None) and part.inline_data.data:
                            with open(fpath, "wb") as f:
                                f.write(part.inline_data.data)
                            return f"IMAGE:{rel}|Готово! Нарисовал по запросу: «{prompt}»."
                    errors.append("Gemini: ответ без картинки")
                except Exception as e:
                    m = str(e)
                    if "429" in m or "RESOURCE_EXHAUSTED" in m: errors.append("Gemini: лимит (429)")
                    elif "403" in m or "PERMISSION" in m or "Forbidden" in m: errors.append("Gemini: доступ (403, VPN/биллинг)")
                    else: errors.append(f"Gemini: {m[:60]}")
            except Exception as e:
                errors.append(f"Gemini-клиент: {str(e)[:60]}")

        # 2) Cloudflare Workers AI (FLUX) — бесплатно, не зависит от Gemini
        cf_acc = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "")
        cf_tok = os.environ.get("CLOUDFLARE_API_TOKEN", "")
        if cf_acc and cf_tok:
            try:
                import urllib.request as _u, json as _j
                url = (f"https://api.cloudflare.com/client/v4/accounts/{cf_acc}"
                       f"/ai/run/@cf/black-forest-labs/flux-1-schnell")
                body = _j.dumps({"prompt": prompt[:2000]}).encode()
                req = _u.Request(url, data=body, headers={
                    "Authorization": f"Bearer {cf_tok}", "Content-Type": "application/json"})
                resp = _u.urlopen(req, timeout=60).read()
                data = _j.loads(resp)
                img_b64 = data.get("result", {}).get("image")
                if img_b64:
                    with open(fpath, "wb") as f:
                        f.write(_b64.b64decode(img_b64))
                    return f"IMAGE:{rel}|Готово! Нарисовал по запросу: «{prompt}» (FLUX)."
                errors.append("Cloudflare: пустой ответ")
            except Exception as e:
                errors.append(f"Cloudflare: {str(e)[:60]}")

        diag = " | ".join(errors) if errors else "нет доступного генератора"
        hint = ""
        if not gkey and not cf_acc:
            hint = " Добавь GEMINI_API_KEY (с VPN) или CLOUDFLARE_ACCOUNT_ID+CLOUDFLARE_API_TOKEN в .env."
        elif "429" in diag:
            hint = " Лимит Gemini исчерпан — подожди сброса (раз в сутки) или добавь Cloudflare-ключ как запаску."
        return ("Не удалось сгенерировать изображение. Причина: " + diag + "." + hint +
                " (Я не выдумываю картинку — честно сообщаю результат.)")

    def deep_research(query: str) -> str:
        """Глубокое исследование (как ресёрчер): несколько поисковых запросов +
        чтение топ-страниц с приоритетом официальных источников. Возвращает
        собранный материал со ссылками — модель делает честный вывод."""
        import re as _re
        collected = []
        sources = []
        seen_urls = set()

        # 1) Делаем НЕСКОЛЬКО запросов: основной + вариации (как человек уточняет).
        queries = [query]
        # добавим вариацию со словами, повышающими шанс найти точные данные
        if not _re.search(r'(?i)(официальн|точн|текст|документ)', query):
            queries.append(query + " официальный источник 2026")

        for q in queries[:2]:
            res = search(q)
            if res and "ничего не найдено" not in res:
                collected.append(f"=== Поиск: «{q}» ===\n{res}")

        # 2) Если есть Tavily — собираем URL'ы из всех запросов и читаем топ-страницы,
        #    отдавая ПРИОРИТЕТ официальным доменам (gov, edu, офиц. сайты компаний).
        if tavily_key:
            try:
                import requests
                all_urls = []
                for q in queries[:2]:
                    try:
                        r = requests.post("https://api.tavily.com/search",
                            json={"api_key": tavily_key, "query": q,
                                  "search_depth": "advanced", "max_results": 5,
                                  "include_answer": False}, timeout=20)
                        for it in r.json().get("results", []):
                            u = it.get("url")
                            if u and u not in seen_urls:
                                all_urls.append(u); seen_urls.add(u)
                    except Exception:
                        continue
                # Приоритет: официальные/научные/документация выше блогов.
                # Универсальные правила для всех тем — не только маркетплейсов.
                def _rank(u):
                    ul = u.lower()
                    # 0 — официальные (госорганы, компании, регуляторы, ЦБ, биржи)
                    if any(d in ul for d in (
                        ".gov", ".gov.ru", "europa.eu", "nih.gov", "who.int",
                        "nalog.ru", "minfin", "cbr.ru", "moex.com", "consultant.ru",
                        "garant.ru", "pravo.gov.ru",
                        "seller.wildberries", "docs.ozon", "seller.ozon",
                        "developer.", "docs.", "official",
                    )):
                        return 0
                    # 1 — наука, документация, энциклопедии
                    if any(d in ul for d in (
                        ".edu", "wikipedia", "britannica", "pubmed", "arxiv",
                        "scholar.google", "mdn.io", "python.org", "ietf.org",
                        "rfc-editor", "w3.org", "habr.com",
                    )):
                        return 1
                    # 2 — всё остальное (блоги, медиа, SEO-статьи)
                    return 2
                all_urls.sort(key=_rank)
                # Если ВСЕ топ-3 источника — это блоги/SEO (Tier 2), явно предупреждаем
                # модель ПЕРЕД содержимым: «не верь цифрам из этих источников».
                # HOTFIX 2026-06-09: словили выдумку «комиссия WB 17%» — Tavily нашёл
                # только wb-calculator.ru, postavleno.ru, mpagency.ru (все Tier 2).
                top3_ranks = [_rank(u) for u in all_urls[:3]]
                if top3_ranks and all(r >= 2 for r in top3_ranks):
                    collected.append(
                        "\n🚨 ПРЕДУПРЕЖДЕНИЕ: все найденные источники — НЕБОЛЬШИЕ БЛОГИ или "
                        "SEO-сайты (нет ни одного офиц.источника, документации, госсайта). "
                        "По тарифам/ставкам/ценам/комиссиям/статистике блоги ЧАСТО дают "
                        "УСТАРЕВШИЕ или усреднённые/выдуманные цифры. КОНКРЕТНЫЕ числа из "
                        "них НЕ называй как факт — пометь «по блогам ~X, но это может быть "
                        "устаревшим — точное в личном кабинете / на офиц.сайте / у "
                        "первоисточника». Веди пользователя в надёжный источник."
                    )
                for u in all_urls[:3]:
                    page = fetch_url(u)
                    if page and not page.startswith("["):
                        collected.append(f"\n=== Содержимое {u} ===\n{page[:2500]}")
                        sources.append(u)
            except Exception as e:
                collected.append(f"[deep: чтение страниц пропущено: {e}]")
        else:
            collected.append("[Совет: задай TAVILY_API_KEY для чтения полных страниц.]")

        result = "\n".join(collected)
        if sources:
            result += "\n\n=== ИСТОЧНИКИ (укажи их в ответе) ===\n" + \
                      "\n".join(f"[{i+1}] {s}" for i, s in enumerate(sources))
        result += ("\n\n[ПАМЯТКА: используй ТОЛЬКО факты из текста выше. Если точного "
                   "ответа/числа здесь НЕТ — честно скажи об этом и НЕ выдумывай. "
                   "Отличай 'упоминание темы' от 'дословного ответа на вопрос'. "
                   "Предложи, как получить точные данные (офиц. сайт/ссылка/скриншот).]")
        return result[:9000]

    tools = [
        Tool("generate_image", "Сгенерировать (нарисовать) изображение по текстовому описанию. Используй, когда просят нарисовать, создать картинку, логотип, иллюстрацию, баннер, концепт и т.п. ВАЖНО: prompt передавай на АНГЛИЙСКОМ языке (переведи запрос пользователя) — так качество намного лучше. Будь подробным в описании (стиль, цвета, детали).",
            {"type":"object","properties":{"prompt":{"type":"string","description":"Подробное описание картинки на английском"}},"required":["prompt"]},
            generate_image),
        Tool("deep_research", "🎯 ОСНОВНОЙ инструмент для поиска фактов в интернете. ВСЕГДА используй для запросов с цифрами/процентами/ценами/тарифами/комиссиями/датами/курсами/статистикой; для слов 'найди', 'поищи', 'актуальный', 'свежий', 'со ссылками', 'в интернете', '2026'. Делает поиск + ЧИТАЕТ страницы целиком + сортирует офиц.источники первыми + возвращает реальные ссылки. На вопросы про комиссии/тарифы/цены/курсы/новости — ОБЯЗАТЕЛЬНО этот инструмент, НЕ web_search.",
            {"type":"object","properties":{"query":{"type":"string","description":"Тема/вопрос для исследования"}},"required":["query"]},
            deep_research),
        Tool("web_search", "Быстрый поиск БЕЗ чтения страниц — только короткие сниппеты и AI-сводка (может врать). Используй ТОЛЬКО для общих определений ('что такое X', 'кто такой Y', 'где находится Z') и нейтральных тем без цифр. Для свежих данных, цифр, цен, тарифов, фактов «найди X» — НЕ используй, бери deep_research.",
            {"type":"object","properties":{"query":{"type":"string","description":"Поисковый запрос"}},"required":["query"]},
            search),
        Tool("calculator", "Математические вычисления",
            {"type":"object","properties":{"expression":{"type":"string","description":"Выражение: 2+2*10"}},"required":["expression"]},
            calc),
        Tool("datetime_now", "Текущие дата и время",
            {"type":"object","properties":{}},
            lambda: time.strftime("%Y-%m-%d %H:%M:%S")),
        Tool("read_file", "Прочитать содержимое файла из рабочей папки агента. Поддерживает текст, PDF, Excel (.xlsx/.xls) и CSV. Для PDF можно указать pages='1-10' (страницы 1-10), pages='last10' (последние 10), pages='5' (только 5-я), pages='all' (все, для коротких PDF). По умолчанию первые 30 страниц, лимит 25К символов. Для длинных PDF делай несколько вызовов с разными pages, или используй search_pdf для поиска ключевого слова.",
            {"type":"object","properties":{
                "path":{"type":"string","description":"Имя файла, напр. notes.txt или doc.pdf"},
                "pages":{"type":"string","description":"Для PDF: диапазон страниц '1-10', 'last10', 'all', или одна страница '5'. По умолчанию первые 30."}
            },"required":["path"]},
            read_file),
        Tool("search_pdf", "Поиск ключевого слова или фразы по ВСЕМУ PDF (включая страницы, которые не попали в read_file). Возвращает фрагменты с тайм-кодами страниц. Используй для длинных документов: договоры, отчёты, инструкции. Например: 'найди в этом договоре пункт про неустойку' → search_pdf('contract.pdf', 'неустойка').",
            {"type":"object","properties":{
                "path":{"type":"string","description":"Имя PDF-файла"},
                "query":{"type":"string","description":"Слово или фраза для поиска"},
                "context":{"type":"integer","description":"Сколько символов контекста вокруг найденного (по умолчанию 200)"}
            },"required":["path","query"]},
            search_pdf),
        Tool("analyze_pdf_page", "Vision-fallback для PDF из сканов/картинок (когда read_file вернул '[PDF без извлекаемого текста]'). Рендерит ОДНУ страницу PDF в картинку и отправляет в analyze_image. ⚠️ ДОРОГО по токенам — используй только для отдельных страниц сканированных PDF, не для целых документов. Для текстовых PDF всегда используй read_file.",
            {"type":"object","properties":{
                "path":{"type":"string","description":"Имя PDF-файла"},
                "page":{"type":"integer","description":"Номер страницы (с 1)"},
                "question":{"type":"string","description":"Что узнать со страницы (необязательно)"}
            },"required":["path","page"]},
            analyze_pdf_page),
        Tool("watch_youtube", "Прочитать СУБТИТРЫ YouTube-видео и получить текст с тайм-кодами. Используй для пересказа видео, ответов на вопросы по содержанию, поиска моментов («на какой минуте говорят про X»), конспектов лекций. В 200+ раз ДЕШЕВЛЕ, чем смотреть кадры через Vision. Работает с любым публичным видео (с ручными или авто-субтитрами). НЕ работает для live, приватных, и редких видео без субтитров — тогда честно скажи об этом пользователю.",
            {"type":"object","properties":{
                "url":{"type":"string","description":"Ссылка на видео: youtube.com/watch?v=..., youtu.be/..., /shorts/..."},
                "language":{"type":"string","description":"Предпочитаемый язык субтитров (по умолчанию 'ru'). Если на этом языке нет — автоматически попробует en и любой доступный."}
            },"required":["url"]},
            watch_youtube),
        Tool("write_file", "Создать/перезаписать файл в рабочей папке агента",
            {"type":"object","properties":{
                "path":{"type":"string","description":"Имя файла"},
                "content":{"type":"string","description":"Содержимое файла"}},"required":["path","content"]},
            write_file),
        Tool("list_files", "Показать список файлов в рабочей папке агента",
            {"type":"object","properties":{"path":{"type":"string","description":"Подпапка (по умолчанию текущая)"}}},
            list_files),
        Tool("analyze_image", "Проанализировать изображение (фото, скриншот, карточку товара, инфографику). Принимает путь к файлу в рабочей папке агента ИЛИ URL картинки. Можно задать вопрос об изображении. Используй, когда нужно 'посмотреть' картинку, описать её, прочитать текст с неё, проанализировать дизайн.",
            {"type":"object","properties":{
                "image":{"type":"string","description":"Путь к файлу (напр. photo.jpg) или URL изображения"},
                "question":{"type":"string","description":"Что узнать об изображении (необязательно)"}},"required":["image"]},
            analyze_image),
        Tool("fetch_url", "Открыть веб-страницу по URL и получить её текстовое содержимое для анализа. Используй, когда нужно прочитать конкретную страницу или статью.",
            {"type":"object","properties":{"url":{"type":"string","description":"Ссылка на страницу, напр. https://example.com/page"}},"required":["url"]},
            fetch_url),
    ]

    if allow_exec:
        tools.append(Tool("run_python", "Выполнить Python-код и вернуть его вывод. Используй для вычислений, анализа данных, проверки кода.",
            {"type":"object","properties":{"code":{"type":"string","description":"Python-код для выполнения"}},"required":["code"]},
            run_python))

    return tools

