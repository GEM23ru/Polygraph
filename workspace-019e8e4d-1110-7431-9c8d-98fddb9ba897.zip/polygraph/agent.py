"""
Polygraph Agent — слой инструментов (function calling).

Поддерживает:
  - OpenRouter (через OpenAI-совместимый tools API)
  - Google Gemini (через нативный function calling)
"""

import json, time, os
from typing import Any
from dataclasses import dataclass


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    func: Any

    def call(self, **kw) -> str:
        try: return str(self.func(**kw))
        except Exception as e: return f"[tool error] {e}"


class Agent:
    """Инструментальный слой над Polygraph."""

    def __init__(self, pg):
        self.pg = pg
        self.tools: dict[str, Tool] = {}

    def register(self, tool: Tool):
        self.tools[tool.name] = tool

    def _tools_schema(self) -> list[dict]:
        return [{"type":"function","function":{
            "name":t.name,"description":t.description,"parameters":t.parameters
        }} for t in self.tools.values()]

    # ===== Google Gemini (нативный function calling) =====
    def _run_via_google(self, msg: str, max_turns: int = 5) -> str | None:
        prov = self.pg.providers.get("google")
        if not prov or not prov.ok:
            return None

        # Конвертируем инструменты в формат Gemini
        from google.genai import types as gt
        gemini_tools = []
        for t in self.tools.values():
            # Конвертируем JSON Schema параметры в формат Gemini Schema
            gemini_tools.append(gt.Tool(
                function_declarations=[gt.FunctionDeclaration(
                    name=t.name,
                    description=t.description,
                    parameters=json.loads(json.dumps(t.parameters))  # через JSON чтобы убрать лишнее
                )]
            ))

        config = gt.GenerateContentConfig(
            tools=gemini_tools,
            max_output_tokens=2048,
        )

        contents = [
            "Ты — агент с инструментами. Если нужен инструмент — вызови его. Если нет — ответь напрямую.",
            msg
        ]

        for _ in range(max_turns):
            try:
                resp = prov.c.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=contents,
                    config=config,
                )

                # Проверяем function calls
                if resp.candidates and resp.candidates[0].content and resp.candidates[0].content.parts:
                    parts = resp.candidates[0].content.parts
                    fc_found = False
                    response_text = ""

                    for part in parts:
                        if hasattr(part, 'function_call') and part.function_call:
                            fc_found = True
                            # Возвращаем результат в чат
                            tool_response = {
                                "function_response": {
                                    "name": part.function_call.name,
                                    "response": {"result": self._execute_tool(
                                        part.function_call.name,
                                        dict(part.function_call.args)
                                    )}
                                }
                            }
                            contents.append(gt.Part.from_function_response(
                                name=part.function_call.name,
                                response={"result": self._execute_tool(
                                    part.function_call.name,
                                    dict(part.function_call.args)
                                )}
                            ))
                        elif hasattr(part, 'text') and part.text:
                            response_text += part.text

                    if not fc_found:
                        return response_text or "[no response]"
                else:
                    return str(resp.text) if hasattr(resp, 'text') else "[no response]"

            except Exception as e:
                return None  # Пробуем следующий провайдер

        return "[max turns]"

    def _execute_tool(self, name: str, args: dict) -> str:
        tool = self.tools.get(name)
        if tool:
            return tool.call(**args)
        return f"[tool not found: {name}]"

    # ===== OpenRouter (OpenAI-совместимый function calling) =====
    def _run_via_openrouter(self, msg: str, max_turns: int = 5) -> str | None:
        prov = self.pg.providers.get("openrouter")
        if not prov or not prov.ok:
            return None

        # Модели, поддерживающие tools
        fc_models = [
            "meta-llama/llama-4-maverick:free",
            "qwen/qwen3-235b-a22b:free",
        ]

        for model_id in fc_models:
            msgs = [
                {"role":"system","content":"Ты — агент с инструментами. Если нужен инструмент — вызови его. Если нет — ответь напрямую."},
                {"role":"user","content":msg}
            ]

            for _ in range(max_turns):
                try:
                    kw = dict(model=model_id, messages=msgs, max_tokens=2048)
                    if self.tools:
                        kw["tools"] = self._tools_schema()
                        kw["tool_choice"] = "auto"

                    r = prov.c.chat.completions.create(**kw)
                    m = r.choices[0].message

                    if m.tool_calls:
                        tcs = [{"id":tc.id,"type":"function","function":{"name":tc.function.name,"arguments":tc.function.arguments}} for tc in m.tool_calls]
                        msgs.append({"role":"assistant","content":m.content or "","tool_calls":tcs})
                        for tc in m.tool_calls:
                            result = self._execute_tool(tc.function.name, json.loads(tc.function.arguments))
                            msgs.append({"role":"tool","tool_call_id":tc.id,"content":result})
                    else:
                        return m.content or "[no response]"
                except Exception:
                    break  # эта модель не сработала, пробуем следующую
            # Если дошли сюда — модель не поддерживает tools, пробуем следующую

        return None

    def run(self, msg: str, max_turns: int = 5) -> str:
        # 1. Сначала пробуем Google Gemini (лучшая поддержка function calling)
        result = self._run_via_google(msg, max_turns)
        if result is not None:
            return result

        # 2. Затем OpenRouter
        result = self._run_via_openrouter(msg, max_turns)
        if result is not None:
            return result

        # 3. Fallback: отвечаем без инструментов
        return self.pg.route(msg)


# ===== Стандартные инструменты =====

def default_tools(tavily_key: str = "") -> list[Tool]:
    def search(query: str) -> str:
        if tavily_key:
            try:
                import requests
                r = requests.post("https://api.tavily.com/search",
                    json={"api_key":tavily_key,"query":query,"search_depth":"basic"}, timeout=10)
                data = r.json()
                items = data.get("results",[])[:5]
                return "\n".join(f"- {it.get('title','')}: {it.get('content','')[:200]}" for it in items)
            except Exception as e:
                return f"[tavily error: {e}]"
        return f"[поиск: '{query}'] — tavily key не задан"

    def calc(expr: str) -> str:
        try:
            return str(eval(expr, {"__builtins__":{}}, {
                "abs":abs,"round":round,"min":min,"max":max,"pow":pow,"sum":sum,"len":len}))
        except Exception as e:
            return f"ошибка: {e}"

    return [
        Tool("web_search","Поиск в интернете",
            {"type":"object","properties":{"query":{"type":"string","description":"Поисковый запрос"}},"required":["query"]},
            search),
        Tool("calculator","Математические вычисления",
            {"type":"object","properties":{"expression":{"type":"string","description":"Выражение: 2+2*10"}},"required":["expression"]},
            calc),
        Tool("datetime_now","Текущие дата и время",
            {"type":"object","properties":{}},
            lambda: time.strftime("%Y-%m-%d %H:%M:%S")),
    ]
